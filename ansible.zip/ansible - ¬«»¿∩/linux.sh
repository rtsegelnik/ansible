Под Root
mount -t vmhgfs .host:/test_ansible /opt/test_ansible
Под admin
cd /opt/test_ansible/
export ANSIBLE_CONFIG="./ansible.cfg"

ssh-keygen -t rsa -b 4096
	/home/admin/.ssh/id_rsa
	/home/admin/.ssh/id_rsa.pub
ssh-copy-id -i ~/.ssh/id_rsa.pub admin@cent1
ssh-copy-id -i ~/.ssh/id_rsa.pub admin@cent2


ssh-copy-id -i ~/.ssh/id_rsa.pub admin@192.168.2.94
ssh-copy-id -i ~/.ssh/id_rsa.pub admin@192.168.2.139
ssh-copy-id -i ~/.ssh/id_rsa.pub root@192.168.2.94
ssh-copy-id -i ~/.ssh/id_rsa.pub root@192.168.2.139

inventory_hostname=/opt/test_ansible/inventory.yml

ansible app1 -m ping
ansible app1 -m command -a "df -h"
ansible